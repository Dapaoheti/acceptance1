/* 离线单测：从 app.js 抽取上传队列/补传函数，stub localStorage+fetch 验证 */
const fs = require('fs');
const src = fs.readFileSync(require('path').resolve(__dirname, '../../acceptance1/app.js'), 'utf8');

/* 抽取：briefKey/countKeyOccurrence/sendBrief/uploadBrief/flushUploadQueue/scheduleFlush + syncWarehouse/feｔchServerRecords/getDashToken */
function grab(name, srcText) {
  const i = srcText.indexOf('function ' + name + '(');
  if (i < 0) throw new Error('not found: ' + name);
  let depth = 0, started = false;
  for (let j = i; j < srcText.length; j++) {
    const c = srcText[j];
    if (c === '{') { depth++; started = true; }
    else if (c === '}') { depth--; if (started && depth === 0) return srcText.slice(i, j + 1); }
  }
  throw new Error('unbalanced: ' + name);
}
const parts = ['briefKey', 'countKeyOccurrence', 'sendBrief', 'uploadBrief', 'flushUploadQueue', 'scheduleFlush', 'getDashToken', 'fetchServerRecords', 'syncWarehouse']
  .map(n => grab(n, src)).join('\n');
/* queue helpers are var-assigned functions: grab manually */
const uqSection = src.slice(src.indexOf('var UQ_KEY'), src.indexOf('function briefKey'));

const store = {};
global.localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; }
};
global.sessionStorage = global.localStorage;
global.window = { prompt: () => 'tok', addEventListener: () => {} };
global.document = { getElementById: () => ({ value: '2026-10' }) };
global.DEFAULT_AI_PROXY = 'mock://scf';
let toasts = [];
global.showToast = (m) => { toasts.push(m); };
global.getLedger = () => Promise.resolve(global.__ledger || []);
const pending = [];
global.fetch = (url, opts) => {
  const body = JSON.parse(opts.body);
  return Promise.resolve(global.__respond(body));
};

eval(uqSection + '\n' + parts);
global.__briefKey = briefKey;

function reportResp(rec) {
  /* 模拟服务端幂等逻辑 */
  const key = briefKey(rec);
  const n = (global.__serverLines.filter(r => briefKey(r) === key)).length;
  if (n > (rec.dupIdx || 0)) return { ok: true, status: 200, json: async () => ({ ok: true, dedup: true }) };
  global.__serverLines.push(rec);
  return { ok: true, status: 200, json: async () => ({ ok: true }) };
}

(async () => {
  global.__serverLines = [];
  let reportCalls = 0, failOn = 0;
  global.__respond = (body) => {
    if (body.action === 'report') {
      reportCalls++;
      if (failOn === reportCalls) return { ok: false, status: 502, json: async () => ({ error: 'x' }) };
      return reportResp(body.record);
    }
    if (body.action === 'records') return { ok: true, status: 200, json: async () => ({ ok: true, month: body.month, records: global.__serverLines }) };
    return { ok: false, status: 400, json: async () => ({}) };
  };

  const mkRec = (i) => ({ date: '2026-10-29', acceptNo: 'YS-' + i, name: '物料' + (i % 2), qty: '1', price: '2', amount: '2', dupIdx: 0 });

  // T1: 队列顺序单发 + 失败退避重试（第2条上报失败→留在队列，重试后补上）
  failOn = 2;
  uploadBrief(mkRec(1));
  uploadBrief(mkRec(2));
  await new Promise(r => setTimeout(r, 1500));
  console.log('T1 after first flush: server=', global.__serverLines.length, 'queue=', JSON.parse(store[UQ_KEY] || '[]').length);
  console.assert(global.__serverLines.length === 1, 'T1 FAIL: only first should succeed');
  console.assert(JSON.parse(store[UQ_KEY]).length === 1, 'T1 FAIL: one item should remain queued');
  // 手动触发重试（退避定时器太慢）
  var q1 = JSON.parse(store[UQ_KEY]); q1[0].nextTs = 0; store[UQ_KEY] = JSON.stringify(q1);
  flushUploadQueue();
  await new Promise(r => setTimeout(r, 200));
  console.log('T1 after retry: server=', global.__serverLines.length, 'queue=', JSON.parse(store[UQ_KEY] || '[]').length);
  console.assert(global.__serverLines.length === 2 && JSON.parse(store[UQ_KEY] || '[]').length === 0, 'T1 FAIL retry');

  // T2: 补传差集（出现次数感知：同键两条，服务端已有1条 → 只补 dupIdx=1 那条）
  global.__serverLines = [Object.assign(mkRec(3), { dupIdx: 0 })];
  global.__ledger = [Object.assign(mkRec(3), { dupIdx: 0 }), Object.assign(mkRec(3), { dupIdx: 1 }), mkRec(4)];
  syncWarehouse();
  await new Promise(r => setTimeout(r, 1500));
  const added = global.__serverLines.filter(r => r.acceptNo === 'YS-3');
  console.log('T2 sync: server YS-3 count=', added.length, 'total=', global.__serverLines.length, 'toasts=', JSON.stringify(toasts.slice(-1)));
  console.assert(added.length === 2, 'T2 FAIL: dupIdx=1 should be added once (total YS-3 = 2)');
  console.assert(global.__serverLines.length === 3, 'T2 FAIL: 1 missing + 1 new key = 3 total');
  console.assert(/补传 2 条/.test(toasts[toasts.length - 1]), 'T2 FAIL toast: ' + toasts[toasts.length - 1]);

  // T3: 幂等——重复补传不重复计数
  toasts = [];
  syncWarehouse();
  await new Promise(r => setTimeout(r, 1500));
  console.log('T3 idempotent sync: total=', global.__serverLines.length, 'toasts=', JSON.stringify(toasts.slice(-1)));
  console.assert(global.__serverLines.length === 3, 'T3 FAIL: no new rows');
  console.assert(/无需补传/.test(toasts[toasts.length - 1]), 'T3 FAIL toast');

  console.log('ALL_CLIENT_TESTS_DONE');
  process.exit(0);
})().catch(e => { console.error('TEST_ERROR', e); process.exit(1); });
