/* 离线单测：mock Gitee contents API，验证 report 追加/去重/并发重试 + records 只读 */
const path = require('path');
process.env.GITEE_TOKEN = 't';
process.env.GITEE_REPO = 'o/r';
process.env.DASHBOARD_TOKEN = 'tk';

const files = {}; // path -> { text, sha, ver }
let writeConflicts = 0;
let failNextWrite = false;

global.fetch = async function (url, opts) {
  const u = String(url);
  if (u.indexOf('/contents/') > -1 && (!opts || !opts.method || opts.method === 'GET')) {
    const p = decodeURIComponent(u.split('/contents/')[1].split('?')[0]);
    if (!files[p]) return { ok: false, status: 404, json: async () => ({}) };
    return { ok: true, status: 200, json: async () => ({ content: Buffer.from(files[p].text).toString('base64'), sha: 'sha' + files[p].ver }) };
  }
  if (u.indexOf('/contents/') > -1 && opts && (opts.method === 'POST' || opts.method === 'PUT')) {
    const p = decodeURIComponent(u.split('/contents/')[1].split('?')[0]);
    const body = JSON.parse(opts.body);
    const cur = files[p];
    if (failNextWrite) { failNextWrite = false; return { ok: false, status: 502, json: async () => ({}) }; }
    if (opts.method === 'POST') {
      /* 真实 Gitee 语义：POST=创建，文件已存在→400 */
      if (cur) return { ok: false, status: 400, json: async () => ({ message: '文件名已存在' }) };
    } else {
      /* PUT=更新，必须带正确 sha */
      if (!cur) return { ok: false, status: 404, json: async () => ({}) };
      if (!body.sha || body.sha !== 'sha' + cur.ver) {
        writeConflicts++; // 模拟并发 lost-update 场景：sha 不匹配即冲突
        return { ok: false, status: 409, json: async () => ({}) };
      }
    }
    files[p] = { text: Buffer.from(body.content, 'base64').toString('utf8'), ver: (cur ? cur.ver : 0) + 1 };
    return { ok: true, status: 201, json: async () => ({}) };
  }
  return { ok: false, status: 500, json: async () => ({}) };
};

const scf = require(path.resolve(__dirname, '../../scf-deploy.js'));

function post(body) {
  if (['report','prices','hashes','usage','ai'].indexOf(body.action) >= 0 && !body.wtoken) body.wtoken = '已脱敏';
  return scf.main_handler({ httpMethod: 'POST', body: JSON.stringify(body) });
}
function lines() {
  const f = files['reports/2026-10.jsonl'];
  return f ? f.text.split('\n').filter(Boolean).map(JSON.parse) : [];
}

(async () => {
  const rec = (dupIdx, extra) => Object.assign({
    date: '2026-10-29', acceptNo: 'YS-001', contractNo: '', project: 'P', name: '电缆',
    unit: '米', qty: '10', price: '5', amount: '50', dupIdx
  }, extra || {});

  // 1) 正常追加
  let r = JSON.parse((await post({ action: 'report', record: rec(0) })).body);
  console.log('T1 first upload:', JSON.stringify(r), 'lines=', lines().length);
  console.assert(r.ok === true && lines().length === 1, 'T1 FAIL');

  // 2) 幂等重试（同 dupIdx=0 再来）→ dedup 跳过
  r = JSON.parse((await post({ action: 'report', record: rec(0) })).body);
  console.log('T2 duplicate retry:', JSON.stringify(r), 'lines=', lines().length);
  console.assert(r.ok === true && r.dedup === true && lines().length === 1, 'T2 FAIL');

  // 3) 同名同额第二条（dupIdx=1）→ 正常写入
  r = JSON.parse((await post({ action: 'report', record: rec(1) })).body);
  console.log('T3 second occurrence:', JSON.stringify(r), 'lines=', lines().length);
  console.assert(r.ok === true && !r.dedup && lines().length === 2, 'T3 FAIL');

  // 4) 并发场景：report 中途他人写入 → sha 冲突自动重读重试，不丢行
  const origGet = global.fetch;
  let injected = false;
  global.fetch = async function (u, o) {
    if (!injected && o && (o.method === 'POST' || o.method === 'PUT') && String(u).indexOf('reports/2026-10.jsonl') > -1) {
      injected = true;
      // 模拟别人刚写过（并发 lost update 制造器）
      const f = files['reports/2026-10.jsonl'];
      f.text += '\n' + JSON.stringify({ acceptNo: 'YS-OTHER', name: '别人写的', qty: 1, price: 1, amount: 1, date: '2026-10-29' });
      f.ver++;
      return origGet(u, o); // 我们的写带旧 sha → 409 → 应重试成功
    }
    return origGet(u, o);
  };
  r = JSON.parse((await post({ action: 'report', record: rec(1, { acceptNo: 'YS-002', name: '插座' }) })).body);
  global.fetch = origGet;
  console.log('T4 concurrent conflict retry:', JSON.stringify(r), 'lines=', lines().length, 'conflicts=', writeConflicts);
  const names = lines().map(x => x.name);
  console.assert(r.ok === true && names.indexOf('别人写的') > -1 && names.indexOf('插座') > -1, 'T4 FAIL lost update');

  // 5) 持续写失败3次 → 502（客户端持久化队列重试）
  let fails = 3;
  global.fetch = async function (u, o) { if (o && (o.method === 'POST' || o.method === 'PUT') && String(u).indexOf('reports/2026-10.jsonl') > -1 && fails > 0) { fails--; return { ok: false, status: 502, json: async () => ({}) }; } return origGet(u, o); };
  r = JSON.parse((await post({ action: 'report', record: rec(2, { acceptNo: 'YS-003', name: '桥架' }) })).body);
  global.fetch = origGet;
  console.log('T5 persistent write fail -> 502:', JSON.stringify(r));
  console.assert(!!r.error, 'T5 FAIL');
  // 5b) 同一记录随后重试成功且不重复（幂等）
  r = JSON.parse((await post({ action: 'report', record: rec(2, { acceptNo: 'YS-003', name: '桥架' }) })).body);
  console.log('T5b retry succeeds:', JSON.stringify(r), 'lines=', lines().length);
  console.assert(r.ok === true && lines().length === 5, 'T5b FAIL');

  // 6) records 只读 + token 校验
  let res = await post({ action: 'records', month: '2026-10', token: 'tk' });
  r = JSON.parse(res.body);
  console.log('T6 records:', res.statusCode, 'count=', r.records.length);
  console.assert(res.statusCode === 200 && Array.isArray(r.records) && r.records.length === 5, 'T6 FAIL');
  res = await post({ action: 'records', month: '2026-10', token: 'bad' });
  console.log('T6b bad token:', res.statusCode);
  console.assert(res.statusCode === 401, 'T6b FAIL');

  // 7) summary 仍可用（只读）
  res = await post({ action: 'summary', month: '2026-10', token: 'tk' });
  r = JSON.parse(res.body);
  console.log('T7 summary totalCount=', r.kpi && r.kpi.totalCount);
  console.assert(r.kpi && r.kpi.totalCount === 5, 'T7 FAIL');

  console.log('ALL_TESTS_DONE');
})().catch(e => { console.error('TEST_ERROR', e); process.exit(1); });
