/* 验证 summary 提速：报价索引优先 + 旧格式回退仅限 JSONL 缺失 */
const path = require('path');
process.env.GITEE_TOKEN = '***';
process.env.GITEE_REPO = 'o/r';
process.env.DASHBOARD_TOKEN = '***';

const files = {};
let apiCalls = 0;
function setFile(p, obj) { files[p] = { text: typeof obj === 'string' ? obj : JSON.stringify(obj), ver: 1 }; }

global.fetch = async function (url, opts) {
  const u = String(url);
  apiCalls++;
  if (u.indexOf('/contents/') > -1 && (!opts || !opts.method || opts.method === 'GET')) {
    const p = decodeURIComponent(u.split('/contents/')[1].split('?')[0]);
    if (!files[p]) {
      /* 目录列举：前缀匹配子项（模拟 Gitee contents API） */
      const kids = Object.keys(files).filter(k => k.indexOf(p + '/') === 0).map(k => ({ name: k.slice(p.length + 1), path: k }));
      if (kids.length) return { ok: true, status: 200, json: async () => kids };
      return { ok: false, status: 404, json: async () => ({}) };
    }
    return { ok: true, status: 200, json: async () => ({ content: Buffer.from(files[p].text).toString('base64'), sha: 'sha1' }) };
  }
  if (u.indexOf('/contents/') > -1 && opts && (opts.method === 'POST' || opts.method === 'PUT')) {
    const p = decodeURIComponent(u.split('/contents/')[1].split('?')[0]);
    const b = JSON.parse(opts.body);
    files[p] = { text: Buffer.from(b.content, 'base64').toString('utf8'), ver: 2 };
    return { ok: true, status: 201, json: async () => ({}) };
  }
  return { ok: false, status: 500, json: async () => ({}) };
};

const scf = require(path.resolve(__dirname, '../../scf-deploy.js'));
const post = (b) => { if (['report','prices','hashes','usage','ai'].indexOf(b.action) >= 0 && !b.wtoken) b.wtoken = '已脱敏'; return scf.main_handler({ httpMethod: 'POST', body: JSON.stringify(b) }); };

(async () => {
  // 场景：JSONL 有2条 + prices/ 下5个旧文件 + prices-index.json 已存在
  setFile('reports/2026-10.jsonl',
    JSON.stringify({ date: '2026-10-01', acceptNo: 'A', name: '电缆', qty: '1', price: '10', amount: '10' }) + '\n' +
    JSON.stringify({ date: '2026-10-02', acceptNo: 'B', name: '插座', qty: '2', price: '5', amount: '10', quotePrice: '6' }));
  for (let i = 0; i < 5; i++) setFile('prices/p' + i + '.json', [{ name: '电缆', price: 8 + i }]);
  setFile('prices-index.json', { '电缆': 9, '插座': 6 });

  const r0 = JSON.parse((await post({ action: 'summary', month: '2026-10', token: '***' })).body);
  const calls1 = apiCalls;
  console.log('T1 summary kpi:', JSON.stringify(r0.kpi), 'apiCalls=', calls1);
  console.assert(r0.kpi.totalCount === 2, 'T1 FAIL count');
  console.assert(calls1 <= 4, 'T1 FAIL: 索引优先应≤4次请求，实际 ' + calls1); // jsonl读+可能目录列表+索引读+summary自身
  const row = r0.rows.find(x => x.name === '电缆');
  console.log('T1 base check: basePrice=', row.basePrice, '(应=9 来自索引而非5个文件的最后值12)');
  console.assert(row.basePrice === 9, 'T1 FAIL: 未走索引');

  // T2: 无索引时回退全扫并固化索引
  delete files['prices-index.json'];
  scf.main_handler; // no cache clear API；等 TTL 内缓存 —— 用新实例不可行，直接看回退路径：改 map ts 无法从外部…换验证 reportPrices 写索引
  const rp = JSON.parse((await post({ action: 'prices', rows: [{ name: '新物料', price: 3 }] })).body);
  console.log('T2 reportPrices:', JSON.stringify(rp), 'prices-index exists=', !!files['prices-index.json']);
  console.assert(rp.ok === true && files['prices-index.json'], 'T2 FAIL: reportPrices 应同步写 prices-index');
  const idx = JSON.parse(files['prices-index.json'].text);
  console.log('T2 index now:', JSON.stringify(idx));
  console.assert(idx['新物料'] === 3, 'T2 FAIL: 新报价应进索引');

  // T3: 旧格式回退——JSONL 空时才扫 reports/<month>/ 旧文件
  apiCalls = 0;
  delete files['reports/2026-11.jsonl'];
  setFile('reports/2026-11/old1.json', { date: '2026-11-01', name: '灯', qty: '1', price: '2', amount: '2' });
  const r3 = JSON.parse((await post({ action: 'summary', month: '2026-11', token: '***' })).body);
  console.log('T3 legacy fallback:', JSON.stringify(r3.kpi));
  console.assert(r3.kpi.totalCount === 1, 'T3 FAIL: JSONL空应回退旧文件');
  console.assert(!!files['reports/2026-11.jsonl'], 'T3 FAIL: 回退后应固化JSONL');

  // T4: JSONL 非空时不得扫旧文件（防超时）
  apiCalls = 0;
  setFile('reports/2026-10/old9.json', { date: '2026-10-03', name: '幽灵', qty: '1', price: '1', amount: '1' });
  const r4 = JSON.parse((await post({ action: 'summary', month: '2026-10', token: '***' })).body);
  console.log('T4 no-scan when jsonl present: totalCount=', r4.kpi.totalCount, 'apiCalls=', apiCalls);
  console.assert(r4.kpi.totalCount === 2, 'T4 FAIL: 不应被旧文件改写');
  console.assert(apiCalls <= 4, 'T4 FAIL: 不应逐文件扫描, calls=' + apiCalls);

  console.log('ALL_SUMMARY_TESTS_DONE');
  process.exit(0);
})().catch(e => { console.error('TEST_ERROR', e); process.exit(1); });
